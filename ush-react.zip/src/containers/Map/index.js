import React from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import styled from 'styled-components';

const Wrapper = styled.div `
	width: auto;
	height: calc(100vh - 56px);
	position: absolute;
	left: 0;
	bottom: 0;
	z-index: 0;
`;

const layerInfo = [
	{
		"imgUrl": "../hamburger.png",
		"imgAlt": "logo",
		"desc": "This is a layer, mama mia"
	},
	{
		"imgUrl": "../road.png",
		"imgAlt": "logo",
		"desc": "that's a spicy meat-a ball!"
	}
];

export default class Map extends React.Component {
	constructor(props) {
		super(props);
	}

	loadLayer = () => {
		console.log("It's working?");
	}

    componentDidMount() {
		this.map = L.map('map', {
            center: [33.749038, -84.388466],
            zoom: 16,
			maxZoom: 20,
            zoomControl: false,
        });

		const sw1000 = L.latLng(33.63298531, -84.51696580),
			  ne1000 = L.latLng(33.93379544, -84.21603335),
			  bounds1000 = L.latLngBounds(sw1000, ne1000);

		const sw200 = L.latLng(33.73327062, -84.41714544),
			  ne200 = L.latLng(33.78337253, -84.31633406),
			  bounds200 = L.latLngBounds(sw200, ne200);

		this.map.options.maxBounds = L.latLngBounds(new L.latLng(33.53, -84.61), new L.latLng(34.03, -84.11));

        var base1000 = L.tileLayer('http://tilemaps.s3-website-us-east-1.amazonaws.com/ATL28_200-1000mosaic/{z}/{x}/{y}.png', {
			bounds: bounds1000,
			minZoom: 11,
			maxNativeZoom: 16,
			maxZoom: 20
        }).addTo(this.map);

		var base200 = L.tileLayer('http://tilemaps.s3-website-us-east-1.amazonaws.com/ATL1928_200mosaic3/{z}/{x}/{y}.png', {
			bounds: bounds200,
			minZoom: 14,
			maxNativeZoom: 19,
			maxZoom: 20,
		}).addTo(this.map); 

		var baseMaps = {
			"1000": base1000,
			"200": base200
		}

		var control = L.control.layers(null, baseMaps, {collapsed: false, autoZIndex: false});
		control.addTo(this.map);
		
		var htmlObject = control.getContainer();
		var parent = document.getElementById('controls');

		parent.appendChild(htmlObject);
		
		L.control.scale().addTo(this.map);

		var inputContainer = document.getElementsByClassName("leaflet-control-layers-overlays");
		var inputs = inputContainer[0].childNodes;
		var layerController = document.getElementsByClassName("layerController");
		var len = inputs.length;

		for(var i = 0; i < len; i++) {
			var label = inputContainer[0].firstChild;
			var obj = layerInfo[i];
			var desc = document.createElement("p");
			var img = <img src={obj.imgUrl} alt={obj.imgAlt} className="layerIcon" />
			desc.innerHTML = obj.desc;
			desc.class = "layerDesc";
			label.appendChild(img);
			label.appendChild(desc);
			document.getElementById("layer"+i).appendChild(label);
		}
    }

	render() {
		return <Wrapper id="map" />
	}
}