import React from 'react';
import styled from 'styled-components';

const Container = styled.div``;

export default class TabInfo extends React.Component {
	render() {
		return <Container>
			<div>
				<p>{this.props.text}</p>
			</div>
		</Container>
	}
}