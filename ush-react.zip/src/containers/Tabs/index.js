import React from 'react';
import styled from 'styled-components';
import TabInfo from './TabInfo.js';

import { Accordion, Button, Card } from 'react-bootstrap';
import Navbar from 'react-bootstrap/Navbar';

var menuIsOpen = false;

const Container = styled.div``;

const accordionStyle = {
	zIndex: 999,
	position: "absolute",
	borderRadius: "0px",
	right: 0,
	top: "56px",
	minHeight: "calc(100vh - 56px)",
	maxHeight: "calc(100vh - 56px)",
	backgroundColor: "#DB504B",
	color: "white"
};

const cardStyle = {
	border: "none",
	borderBox: "none",
	borderRadius: "0px"
}

const cardHeaderStyle = {
	borderBox: "none",
	border: "none",
	borderRadius: "0px",
	padding: 0,
	margin: 0,
	minHeight: "2em",
	maxHeight: "2em",
	backgroundColor: "#DB504B",
	color: "white",
	padding: "0.25em 1.5em",
	fontWeight: "bolder"
}

const cardBodyStyle = {
	height: "calc((100vh - 56px) - (3*2em))",
	color: "#b1b1b1",
	padding: "1em 2em"
}

class ControlStyle extends React.Component {
	render() {
		return <style type="text/css">
		{`
			#controls > div {
				border: none;
				border-radius: 0;
				box-shadow: none;
			}

			.leaflet-control-layers-overlays label {
				margin: 20px;
				color: #DB504B;
			}
		`}
		</style>
	}
}

class HeaderStyle extends React.Component {
	render() {
		return <style type="text/css">
		{`
			#menuControl {
				position: absolute;
				right: 18px;
				top: 0;
				font-size: 36px;
			}

			@media (max-width: 768px) {
				#menuControl {
					display: inline-block;
				}
			} 
			
			@media (min-width: 769px) {
				#menuControl {
					display: none;
				}
			}
		`}	
		</style>
	}
}

class Header extends React.Component {
	render() {
		return <Container>
			<style type="text/css">
				{`
				.navbar-red {
					background-color: #DB504B;
					color: white;
					min-width: 100vw;
					position: fixed;
					top: 0;
					left: 0;
				} 

				.navbar-brand {
					text-decoration: none;
					font-weight: bolder;
					color: white;
				}

				.navbar-brand:hover {
					text-decoration: none;
					color: white;
				}
				`}
			</style>

			<Navbar variant="red">
				<Navbar.Brand href="#">OpenWorld Atlanta</Navbar.Brand>
				<span id="menuControl" ref="MenuControl" ><img href="../hamburger.svg"/></span>
			</Navbar>
		</Container>;
	}
}

export default class Tabs extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
		<>
			<HeaderStyle />
			<Header />
			<Accordion style={accordionStyle} defaultActiveKey="0" id="sidebar" ref="Sidebar">
				<Card style={cardStyle}>
					<Accordion.Toggle as={Card.Header} style={cardHeaderStyle} variant="link" eventKey="0">
						LAYERS
					</Accordion.Toggle>
					<Accordion.Collapse eventKey="0">
						<Card.Body style={cardBodyStyle}>
							<TabInfo text={"A Layer is a type of dataset that can be overlain on top of the base map, and contains data points that belong to the same category of data."} />
							<ControlStyle />
							<div id="controls">
								<div className="layerController" id="layer0" />
								<div className="layerController" id="layer1" />
							</div>
						</Card.Body>
					</Accordion.Collapse>
				</Card>
				<Card style={cardStyle}>
					<Accordion.Toggle as={Card.Header} style={cardHeaderStyle} variant="link" eventKey="1">
						FEATURES
					</Accordion.Toggle>
					<Accordion.Collapse eventKey="1">
						<Card.Body style={cardBodyStyle}>Features Tab</Card.Body>
					</Accordion.Collapse>
				</Card>
				<Card style={cardStyle}>
					<Accordion.Toggle as={Card.Header} style={cardHeaderStyle} variant="link" eventKey="2">
						INFORMATION
					</Accordion.Toggle>
					<Accordion.Collapse eventKey="2">
						<Card.Body style={cardBodyStyle}>Information Tab</Card.Body>
					</Accordion.Collapse>
				</Card>
			</Accordion>
		</>
		);
	}
}