import React from 'react';
import Map from '../Map';
import Tabs from '../Tabs';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import styled from 'styled-components';

const AppWrapper = styled.div`
	display: flex;
	justify-content: center;
	margin-top: 100px;
`;

const Container = styled.div``;

class MediaStyle extends React.Component {
	render() {
		return <style type="text/css">
		{`
		@media (max-width: 768px) {
			#map {
				min-width: 100vw;
				max-width: 100vw;
			}
			#sidebar {
				min-width: 100vw;
				max-width: 100vw;
			}
		}

		@media (min-width: 769px) {
			#map {
				min-width: calc(100% - 500px);
				max-width: calc(100% - 500px);
			}
			#sidebar {
				min-width: 500px;
				max-width: 500px;
			}
		}
		`}
		</style>
	}
}

export default class App extends React.Component {

	constructor(props) {
		super(props);
	}

	render() {
		return (
			<AppWrapper>
				<MediaStyle />
				<Container>
					<Map />
				</Container>
				<Container>
					<Tabs />
				</Container>
			</AppWrapper>
		);
	}
}
